# dNdS gene-by-gene comparative genomics pipeline (v3.0)

### Pipeline (in SLURM-mediated high performance computer)

1. `bash 00_blastn.sh [../relative/path/2/reference_cds_genome.fa]`
0. `bash 01_dbSum.sh [../relative/path/2/reference_cds_genome.fa]`
