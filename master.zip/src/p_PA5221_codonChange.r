#!/bin/Rscript
# author: ph-u
# script: PA5221_codonChange.r
# desc: extract changes in codons for PA5221
# in: Rscript PA5221_codonChange.r
# out: NA
# arg: 0
# date: 20240406

##### Extract pathway that PA5221 is involved #####
source("p_metabolism_PAO1.r")
PAO1.bioc[grep("PA5221", PAO1.bioc$Genes),]

##### Extract codon changes in clinical PA #####
library(ape)
r0 = read.csv(paste0(pT[3], "PAO1_107_PA5221--rDNDS.csv"), header = T)
f = as.character(read.FASTA(paste0(pT[3], "00_PAO1_107_PA5221_db.fa"), type = "DNA"))
i0 = 1; r01 = unique(r0$clinical[is.infinite(r0$dNdS)]); for(i in 1:length(r01)){i0 = c(i0, grep(r01[i], names(f)))};rm(i)
f0 = f[i0]
for(i in 2:length(f0)){cat(names(f0)[i], "\n");print(mEta[which(mEta$assemblyInfo.genbankAssmAccession == strsplit(r01[i-1], "_ASM")[[1]][1]),c("sOurce", "cOuntry")]);print(dNdS.rt(paste0(f0[[1]], collapse = ""), paste0(f0[[i]], collapse = "")))};rm(i)
