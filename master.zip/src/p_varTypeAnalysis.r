#!/bin/env Rscript
# author: ph-u
# script: varTypeAnalysis.r
# desc: variation type analysis - clustering, ordinal principal components
# in: Rscript varTypeAnalysis.r
# out: res/vta_*.pdf
# arg: 0
# date: 20240309

qCol = c("sOurce", "Src") # c({sOurce, gLoc, samType}, {Src, Loc, Typ})
library(Biostrings); library(cluster); library(ape); source("p_src.r")
wGvt = as.character(readDNAStringSet(paste0(pT[1],"varTypeAASeq.fa")))
cBp = c(palette.colors(palette = "Okabe-Ito", alpha = 1), palette.colors(palette = "Alphabet", alpha = 1))
countryLoc = read.csv("../raw/countryLoc.csv", header = T)

##### Set sample type colours #####
if(qCol[2] == "Src"){qCol0 = c(1,2,4,6,10)}else if(qCol[2] == "Loc"){qCol0 = c(1:4,6:10)}else if(qCol[2] == Typ){qCol0 = c(1,2,4,6)}
mEta$gLoc = countryLoc$Continent[match(mEta$cOuntry, countryLoc$Country)]
mEta$samType = ifelse(is.na(mEta$assemblyInfo.biosample.attributes.sample_type),"Unknown",mEta$assemblyInfo.biosample.attributes.sample_type)
isoCol = data.frame(src = unique(mEta[,qCol[1]]), cOl = cBp[qCol0])
w.Col = data.frame(src = names(wGvt), tYpe = NA)
for(i in 1:nrow(w.Col)){
    w.Col$tYpe[i] = mEta[grep(strsplit(w.Col$src[i], "_")[[1]][2], mEta$assemblyInfo.genbankAssmAccession),qCol[1]]
};rm(i)

##### Convert variation type sequence into data frame #####
w.AAdf = as.data.frame(matrix(nr = length(wGvt), nc = nchar(wGvt[1])))
row.names(w.AAdf) = names(wGvt)

cat("Converting sequences into dataframe:",date(),"\n")
for(i in 1:length(wGvt)){
    cat(i,"/",length(wGvt),"(",round(i/length(wGvt)*100,2),"% ) ;",date(),"   \r")
    w.AAdf[i,] = strsplit(wGvt[i], "")[[1]]
};rm(i)
for(i in 1:ncol(w.AAdf)){w.AAdf[,i] = as.factor(w.AAdf[,i])};rm(i)

##### Hierarchical Clustering #####
cat("\nHierarchical Clustering:",date(),"\n")
w.dist = daisy(w.AAdf,"gower") # dissimilarity matrix (any data type: numeric, categorical, mixed)
w.hclust = hclust(w.dist, method = "average") # clustering

pdf(paste0(pT[2],"vta_clus_",qCol[2],".pdf"), width = 20, height = 90) # Src, Loc, Typ
plot(as.phylo(w.hclust), tip.color = isoCol$cOl[match(w.Col$tYpe,isoCol$src)])
legend("topleft", legend = isoCol$src, fill = isoCol$cOl, cex = 6)
invisible(dev.off())
save(w.AAdf,isoCol, w.Col, cBp, file = paste0(pT[1],"vta_data_",qCol[2],".rda"))
