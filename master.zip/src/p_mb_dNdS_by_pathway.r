#!/bin/env Rscript
# author: ph-u
# script: mb_dNdS_by_pathway.r
# desc: analysis of dN/dS differences pathway by pathway
# in: Rscript mb_dNdS_by_pathway.r
# out: NA
# arg: 0
# date: 20240405

source("p_src.r")
r0 = read.csv(paste0(pT[1],"metabolic_dNdS_test.csv"), header = T)
r0 = r0[!is.na(r0$dNdS),]
r0.pathway = unique(r0$metabolism)
r0.gene = unique(r0$gene)

cat("\n\n")
print(pairwise.wilcox.test(r0$dNdS, r0$sRc, p.adjust = "bonf"))
cat("\n\n")

x00 = r0.gene
i0=0; for(i in 1:length(r0.gene)){
    r0.0 = r0[which(r0$gene == x00[i]),]
    if(sum(!is.na(r0.0$dNdS)) > 30){
        r0.wil = pairwise.wilcox.test(r0.0$dNdS, r0.0$sRc, p.adjust = "none")
        r0.rec = data.frame(cond = x00[i], g1 = rep(colnames(r0.wil$p.value), each = nrow(r0.wil$p.value)), g2 = row.names(r0.wil$p.value), p.raw = as.numeric(r0.wil$p.value))
        if(i0==0){r0.re0 = r0.rec[!is.na(r0.rec$p.raw),]; i0=1}else{r0.re0 = rbind(r0.re0, r0.rec[!is.na(r0.rec$p.raw),])}
}};rm(i, x00)
r0.re0$p.bh = p.adjust(r0.re0$p.raw, method = "BH")

print(r0.re0[which(r0.re0$p.bh<.05),])
