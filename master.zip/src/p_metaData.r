#!/bin/env Rscript
# author: ph-u
# script: 01_metaData.r
# desc: clinical strains metadata reconstruction
# in: Rscript 01_metaData.r
# out: NA
# arg: 0
# date: 20240307

source("../src_hpc/metaPrep.r")
pT = c(paste0("../",c("raw","res"),"/"),"/media/pokman/Transcend/PAO1_dNdS/data/")
pAthways = read.table(paste0(pT[1],"pathways.txt"), header = T, sep = "\t", comment.char="", quote="") # gene pathways involved
#geneCat = read.table(paste0(pT[1],"Pseudomonas aeruginosa PAO1 (Stover et al., 2000)_cog_tab.txt"), header = T, sep = "\t", comment.char="", quote="") # gene functions

library(openxlsx)
vIrulence = readWorkbook(paste0(pT[1], "virulence_factors.xlsx"))

##### filter possible assessory genes #####
twoAllele = read.csv(paste0(pT[1],"PA_two_allele_library.csv"), header = T) # transposon mutants
twoAllele = twoAllele[which(twoAllele$Position.in.ORF!=""),]
twoAllele$pos = twoAllele$tot = NA

i0 = grep("[(]", twoAllele$Position.in.ORF)
i1 = read.table(text = gsub("[)]","",twoAllele$Position.in.ORF[i0]), sep = "(")
twoAllele$pos[i0] = i1[,1]
twoAllele$tot[i0] = i1[,2]

i0 = grep("-", twoAllele$Position.in.ORF)
twoAllele$pos[i0] = as.numeric(twoAllele$pos[i0])
# !!!!!

rmTag = c()
for(i in 1:nrow(twoAllele)){ if(length(grep("[(]",))){}else if(){}else if(){}else{}};rm(i)
twoAllele = twoAllele[-rmTag,]
rm(rmTag)

##### import dN/dS sequence windows ##### (34 mins)
cat("Import dN/dS information:",date(),"\n")
paLst = gsub("^01_","00_",list.files(pT[3], "^01_"))

for(i in 1:length(paLst)){
    cat(i, "/", length(paLst), ":", round(i/length(paLst)*100,2), "% -", date(), "       \r")
    x = read.csv(paste0(pT[3],paLst[i]), header = T)

## Sequence variation type extraction
    x$varType = x$sampleEnv = x$cOuntry = NA
    for(i0 in grep("%", x$locus)){
        x$varType[i0] = strsplit(x$locus[i0],"%")[[1]][1]
    };rm(i0)
    x$varType[is.na(x$varType)] = "SNP"

## Sample source
    for(i1 in 1:nrow(mEta)){
        i0 = grep(mEta$assemblyInfo.genbankAssmAccession[i1], x$clinical)
        x$sampleEnv[i0] = mEta$sOurce[i1]
        x$cOuntry[i0] = mEta$cOuntry[i1]
    };rm(i1, i0)
    x = x[which(x$sampleEnv=="Cystic fibrosis"),] # focus only on CF


    if(i==1){
        varMode = x
    }else{varMode = rbind(varMode, x)}
};rm(i, x)
