#!/bin/env Rscript
# author: ph-u
# script: varTypeBar_s.r
# desc: sequence variation type in all PAO1 protein-coding genes (small plot)
# in: Rscript varTypeBar_s.r
# out: res/vt_Bar_s.pdf
# arg: 0
# date: 20240425

source("p_src.r")
teS = read.csv(paste0(pT[2],"vt_Bar.csv"), row.names = 1, header = T)
x0 = which(row.names(teS)=="PA2230")
teS = t(teS[(x0-99):x0,])

cat("\nPlotting:",date(),"\n")
x0 = 3; x1 = round(ncol(teS)/x0)
pdf(paste0(pT[2],"vt_Bar_s.pdf"), width = x1*.6, height = x0*3)
par(mar = c(5,4,1,6)+.1, mfrow = c(x0,1), xpd = T)
for(i in 1:x0){
    barplot(teS[,(x1*(i-1)+1):min(x1*i,ncol(teS))], col = cBp, ylab = "IPCD isolates (%; 100% = 854 isolates)")
};rm(i)
legend("topright", legend = row.names(teS), pch = 20, cex = 1.2, col = cBp, inset = c(-.04,0))
invisible(dev.off())
cat("Exported barplot:",date(),"\n")
