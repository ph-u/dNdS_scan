#!/bin/env Rscript
# author: ph-u
# script: geneTop20SNP.r
# desc: scan overall dN/dS for each clinical isolates within the top 20 genes under extreme negative/neutral/positive selection
# in: Rscript geneTop20SNP.r
# out: data/geneTop20SNP.csv
# arg: 0
# date: 20240327

options(warn=2)
source("p_src.r"); library(ape)
vtBar = read.csv(paste0(pT[1],"vt_SNP_dist.csv"), header = T, row.names = 1) # paste0(pT[2],"vt_Bar.csv")
pao1 = as.character(read.FASTA("../raw/PAO1_107.fa", type = "DNA"))
f.clin = list.files(pT[3],"_db.fa$")

r0.c = c("gene", "clinical", "dNdS", "pN", "pS", "Nd", "Sd", "N", "S")
#xSt = row.names(vtBar)[rev(order(vtBar$SNP))[1:20]]
xSt = c(); for(i in 1:ncol(vtBar)){
    xSt = c(xSt, row.names(vtBar)[rev(order(vtBar[,i]))[1:20]])
};rm(i)

cat("SNP dN/dS overall gene calculation:",date(),"\n")
for(i in 1:length(xSt)){
    p0 = paste0(pao1[[grep(paste0(xSt[i],";"),names(pao1))]], collapse = "")
    dSq = as.character(read.FASTA(paste0(pT[3],f.clin[grep(paste0(xSt[i],"_"),f.clin)]), type = "DNA"))
    r0 = as.data.frame(matrix(nr = length(dSq), nc = length(r0.c)))
    colnames(r0) = r0.c
    r0$gene = xSt[i]
    r0$clinical = read.table(text=gsub("_ASM","@",names(dSq)), sep = "@")[,1]
    for(i0 in 1:nrow(r0)){
        cat(i0,"/",length(dSq),"; (",round(i0/length(dSq)*100,0),"% ) in",i,"/",length(xSt),"; (",round(i/length(xSt)*100,0),"% )",xSt[i], date(), "  \r")
        if(substr(p0,1,3)==paste0(dSq[[i0]][1:3], collapse = "") & nchar(p0)==length(dSq[[i0]][which(dSq[[i0]]!="-")])){ # only consider full genes
            r0[i0,-(1:2)] = dNdS.rt(tolower(p0), tolower(paste0(dSq[[i0]][which(dSq[[i0]]!="-")], collapse = "")))[[1]]
    }}
    if(i==1){write.csv(r0, paste0(pT[1],"geneTop20SNP_n0p.csv"), row.names = F, quote = F)}else{write.csv(rbind(read.csv(paste0(pT[1],"geneTop20SNP_n0p.csv"), header = T), r0), paste0(pT[1],"geneTop20SNP_n0p.csv"), row.names = F, quote = F)}
};rm(i, i0)
cat("\nSNP dN/dS overall gene calculation done:",date(),"\n")
