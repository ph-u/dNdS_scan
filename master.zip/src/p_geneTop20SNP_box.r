#!/bin/env Rscript
# author: ph-u
# script: geneTop20SNP_box.r
# desc: boxplot for top 20 SNP genes dN/dS distribution
# in: Rscript geneTop20SNP_box.r
# out: NA
# arg: 0
# date: 20240327

source("p_src.r")
gS = read.csv(paste0(pT[1],"geneTop20SNP_n0p.csv"), header = T)
gS$dNdS = ifelse(is.finite(gS$dNdS),gS$dNdS,ceiling(max(gS$dNdS)+9))

pdf(paste0(pT[2],"geneTop20SNP_box_n0p.pdf"), width = length(unique(gS$gene)))
par(mar = c(2,4,1,0)+.1)
boxplot(gS$dNdS ~ as.factor(gS$gene), xlab = "", ylab = "dN/dS", col = "#00000000")
abline(h=1, lty = 2, col = cBp[2])
invisible(dev.off())
