#!/bin/env Rscript
# author: ph-u
# script: p_src.r
# desc: env setting for whole genome dN/dS analyses
# in: source("p_src.r")
# out: NA
# arg: 0
# date: 20240309

p0 = getwd()
setwd("../../1_02_wholeGenomeDNDS/dNdSGenome");source("src_dNdS.r")
setwd("../src_hpc");source("metaPrep.r")
setwd(p0);rm(p0)
pT = c(paste0("../",c("data","res"),"/"), "/media/pokman/Transcend/PAO1_dNdS/data/", "../raw/")

source("src.r")
