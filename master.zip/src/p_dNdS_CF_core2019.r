#!/bin/env Rscript
# author: ph-u
# script: p_dNdS_CF_core2019.r
# desc: extract CF dN/dS from 2019 core genome paper from PA14
# in: Rscript p_dNdS_CF_core2019.r
# out: res/pnas.1900570116.modData-CFdnds.csv
# arg: 0
# date: 20240809

source("p_src.r")
f.IN = "pnas.1900570116.modData"

r0.r = read.csv(paste0(pT[1],f.IN,".csv"), header = T)

r0.r$CF.dNdS.median = NA
i0 = list.files(pT[3],"-dbSum")
cf.ref = mEta$assemblyInfo.genbankAssmAccession[grep("Cys", mEta$sOurce)]
cat("Scanning dNdS central tendency:",date(),"\n")
for(i in 1:nrow(r0.r)){ cat(i,"/",nrow(r0.r),"(",round(i/nrow(r0.r)*100,1),"):",date(),"     \r"); if(!is.na(r0.r$PAnum.QC[i])){
    a0.r = read.csv(paste0(pT[3],i0[grep(paste0("_",r0.r$PAnum.QC[i],"-"), i0)]), header = T)
    a0.r$dNdS = abs(a0.r$dNdS)
    a0.r = a0.r[which(read.table(text = gsub("_ASM","@",a0.r$clinical), sep = "@")[,1] %in% cf.ref),]
    r0.r$CF.dNdS.median[i] = median(a0.r$dNdS, na.rm = T)
}};rm(i, a0.r);cat("\n")

write.csv(r0.r, paste0(pT[2],f.IN,"-CFdnds.csv"), row.names = F, quote = F)
