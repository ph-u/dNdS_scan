#!/bin/env Rscript
# author: ph-u
# script: geneTop20SNP_pca.r
# desc: multivariate test for top 20 SNP genes
# in: Rscript geneTop20SNP_pca.r
# out: NA
# arg: 0
# date: 20240327

source("p_src.r"); source("../src_hpc/metaPrep.r"); source("seqTypingID.r"); library(pcaMethods)
countryLoc = read.csv("../raw/countryLoc.csv", header = T)
mEta$gLoc = countryLoc$Continent[match(mEta$cOuntry, countryLoc$Country)]
## sequence type
mEta$seqT = seqType$ST[match(mEta$assemblyInfo.genbankAssmAccession, seqType$clinical)]
mEta$seqT[is.na(mEta$seqT)] = mEta$seqT[grep(";",mEta$seqT)] = "Ambiguous"
mEta$seqT[which(mEta$seqT!="Ambiguous")] = paste0("ST",mEta$seqT[which(mEta$seqT!="Ambiguous")])
#mEta$gSrc = paste0(mEta$gLoc,"-",mEta$sOurce)
#mEta$inFect = ifelse(mEta$sOurce %in% c("Cystic fibrosis", "Other infections"), "infection", "non-infection")
gS = read.csv(paste0(pT[1],"geneTop20SNP_n0p.csv"), header = T)

r0 = as.data.frame(matrix(nr = length(unique(gS$clinical)), nc = length(unique(gS$gene))+1))
colnames(r0) = c("src", unique(gS$gene))
row.names(r0) = unique(gS$clinical)
gS = gS[!is.na(gS$dNdS),]

##### Map dN/dS values & sample sources #####
r0$src = mEta$gLoc[match(row.names(r0), mEta$assemblyInfo.genbankAssmAccession)] # sOurce, gLoc, !cOuntry, !gSrc, !seqT (overfitted, https://stats.stackexchange.com/questions/55925/the-leading-minor-of-order-1-is-not-positive-definite-error-using-2l-norm-in-m)
cat("Mapping dN/dS values:",date(),"\n")
for(i in 1:nrow(gS)){
    cat(i,"/",nrow(gS),"(",round(i/nrow(gS)*100,2),"% )",date(),"     \r")
    r0[which(row.names(r0)==gS$clinical[i]),which(colnames(r0)==gS$gene[i])] = ifelse(is.finite(gS$dNdS[i]),gS$dNdS[i],ceiling(max(gS$dNdS)+9))
};rm(i);cat("\nMapping dN/dS values done:",date(),"\n")
i0 = numeric(nrow(r0));for(i in 1:nrow(r0)){i0[i] = sum(is.na(r0[i,-1]))};rm(i) # detect any clinical isolates not matching criteria on every listed gene
if(length(which(i0==(ncol(r0)-1))) > 0){
    cat(rownames(r0)[which(i0==(ncol(r0)-1))],"(",r0$src[which(i0==(ncol(r0)-1))],") has all genes marked NA, removed from subsequent analysis\n")
    r0 = r0[-which(i0==(ncol(r0)-1)),]};rm(i0)

##### PCA with NAs ##### !!can only run in bash terminal / fresh R as mixOmics masks func pca()
r.pca = pcaSwap(r0[,-1]) # require no inf
r.ppca = pcaMethods::pca(r0[,-1], method = "ppca") # require no inf

p.r = ggbiplot(r.pca, obs.scale = 1, var.scale = 1, groups = as.factor(r0$src), ellipse = TRUE, ellipse.prob = 0.95) + theme_bw() +
    scale_color_manual(values=setNames(cBp[1:length(unique(r0$src))], unique(r0$src)[order(unique(r0$src))])) +
    guides(color=guide_legend(title="Sample source")) +
    theme(legend.position = 'bottom', legend.direction = "vertical",
        panel.grid.major = element_blank(),panel.grid.minor = element_blank(),
	legend.title = element_text(size=18),
	axis.text=element_text(size=16),axis.title=element_text(size=14),
	plot.margin=margin(t=0,r=0,b=0,l=1))
ggsave(paste0(pT[2],"geneTop20SNP_biplot_n0p.pdf"), plot = pcaLAB(p.r,round(r.ppca@R2*100,1)), width = 6, height = 7)

##### PLSDA #####
library(mixOmics)
r.plsda = plsda(r0[,-1], as.factor(r0$src))
pdf(paste0(pT[2],"geneTop20SNP_plsda_n0p.pdf"), width = 6, height = 7)
plotIndiv(r.plsda, pch=20, ellipse=T, ellipse.level=.95, col = cBp[1:length(unique(r0$src))], size.xlabel=rel(1.4), size.ylabel=rel(4), size.axis=rel(2), legend=T, style="graphics", cex=1)
invisible(dev.off())
