#!/bin/env Rscript
# author: ph-u
# script: indelSNP.r
# desc: scan sub-types within indel and SNP for the top 20 genes on each list
# in: Rscript indelSNP.r
# out: data/indelSNP.csv
# arg: 0
# date: 20240323

source("p_src.r")
library(ape); library(msa)
vtBar = read.csv(paste0(pT[2],"vt_Bar.csv"), header = T, row.names = 1)
pao1 = as.character(read.FASTA("../raw/PAO1_107.fa", type = "DNA"))
f.DNDS = gsub("^01_","00_",list.files(pT[3],"^01_"))
f.clin = list.files(pT[3],"_db.fa$")
r0.c = c("PAnum", "clinical", "insertLen", "frameshift", "snpCount")

##### check indel sub-types #####
cat("Indel sub-types:",date(),"\n")
xSt = row.names(vtBar)[rev(order(vtBar$INDEL))[1:20]]
for(i in 1:length(xSt)){ # 19 yet done
    p0 = paste0(pao1[[grep(xSt[i],names(pao1))]], collapse = "")
    dSt = read.csv(paste0(pT[3],f.DNDS[grep(xSt[i],f.DNDS)]), header = T)
    dSt = dSt$clinical[grep("^INDEL%", dSt$locus)] # clinical isolates for checking
    dSq = as.character(read.FASTA(paste0(pT[3],f.clin[grep(xSt[i],f.clin)]), type = "DNA"))

    ## record df
    r0 = as.data.frame(matrix(nr = length(dSt), nc = length(r0.c)))
    colnames(r0) = r0.c

    for(i0 in 1:length(dSt)){
        cat(i0,"/",length(dSt),"; (",round(i0/length(dSt)*100,2),"% ) in",i,"/",length(xSt),"; (",round(i/length(xSt)*100,2),"% )", date(), "     \r")
        if(i==19){ # this gene is 6Kbp, RAM insufficient, need alternative
            fsNum = abs(nchar(p0)-nchar(paste0(dSq[[grep(dSt[i0], names(dSq))]], collapse = "")))
        }else{
            capture.output(m0 <- msa(c(p0, paste0(dSq[[grep(dSt[i0], names(dSq))]], collapse = "")), method = "ClustalOmega", type = "dna"), file = "/dev/null") # https://stackoverflow.com/questions/2723034/suppress-output-of-a-function
            fsNum = length(grep("[?]",strsplit(msaConsensusSequence(m0), "")[[1]]))
        }
        r0[i0,] = c(xSt[i], dSt[i0], fsNum, fsNum %% 3, NA)
    }

    if(i==1){write.csv(r0, paste0(pT[1],"indelSNP.csv"), row.names = F, quote = F)}else{write.csv(rbind(read.csv(paste0(pT[1],"indelSNP.csv"), header = T), r0), paste0(pT[1],"indelSNP.csv"), row.names = F, quote = F)}
};rm(i, i0, r0, p0, dSt, dSq, m0);cat("\n")

##### check SNP sub-types #####
cat("SNP sub-types:",date(),"\n")
xSt = row.names(vtBar)[rev(order(vtBar$SNP))[1:20]]
for(i in 1:length(xSt)){
    p0 = paste0(pao1[[grep(xSt[i],names(pao1))]], collapse = "")
    dSt = read.csv(paste0(pT[3],f.DNDS[grep(xSt[i],f.DNDS)]), header = T)
    if(length(grep("%", dSt$locus)) > 0){
        dSt = dSt$clinical[-grep("%", dSt$locus)] # clinical isolates for checking
    }else{dSt = dSt$clinical}
    dSq = as.character(read.FASTA(paste0(pT[3],f.clin[grep(xSt[i],f.clin)]), type = "DNA"))

    ## record df
    r0 = as.data.frame(matrix(nr = length(dSt), nc = length(r0.c)))
    colnames(r0) = r0.c

    for(i0 in 1:length(dSt)){
        cat(i0,"/",length(dSt),"; (",round(i0/length(dSt)*100,2),"% ) in",i,"/",length(xSt),"; (",round(i/length(xSt)*100,2),"% )", date(), "     \r")
        r0[i0,] = c(xSt[i], dSt[i0], NA, NA, nrow(dNdS.rt(p0, paste0(dSq[[grep(dSt[i0], names(dSq))]], collapse = ""))[[2]]))
    }

    write.csv(rbind(read.csv(paste0(pT[1],"indelSNP.csv"), header = T), r0), paste0(pT[1],"indelSNP.csv"), row.names = F, quote = F)
};rm(i, i0, r0, p0, dSt, dSq, r0.c);cat("\n")

r0 = read.csv(paste0(pT[1],"indelSNP.csv"), header = T)
r0$clinical = read.table(text = gsub("_ASM", "@",r0$clinical), sep = "@")[,1]
write.csv(r0, paste0(pT[1],"indelSNP.csv"), row.names = F, quote = F)
