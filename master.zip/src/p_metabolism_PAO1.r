#!/bin/env Rscript
# author: ph-u
# script: p_metabolism_PAO1.r
# desc: import PAO1 metabolic pathway csv categorizations from 10.1038/ncomms14631
# in: source("p_metabolism_PAO1.r")
# out: NA
# arg: 0
# date: 20240319

source("p_src.r")
cBt = c();for(i in c("Okabe-Ito", "alphabet", "polychrome 36", "dark 2", "set 1", "classic tableau")){cBt = c(cBt, rev(palette.colors(palette = i, alpha=1, recycle = F)))};rm(i);cBt = unique(cBt)
PAO1.bioc = unique(read.table("../p_pdf/metabolic_41467_2017_BFncomms14631_MOESM2305_ESM.csv", sep = "\t", header = T, skip = 2, fill = T, quote = "")[,c(6,8)])

gBioc = data.frame(protList = protList, metabolism = "Unknown")
for(i in 1:nrow(gBioc)){
    i0 = grep(gBioc$protList[i],PAO1.bioc$Genes)
    if(length(i0) == 1){gBioc$metabolism[i] = PAO1.bioc$Subsystems[i0]}else
    if(length(i0) > 1){
        i1 = unique(PAO1.bioc$Subsystems[i0])
        if(length(i1) == 1){gBioc$metabolism[i] = i1}else{gBioc$metabolism[i] = "Multiple"}}
};rm(i, i0, i1)

##### Metabolism grouping #####
gBioc$metabolism[gBioc$metabolism=="None"] = "Others"
gBioc$metabolism[grep("Terpenoid", gBioc$metabolism)] = "Terpenoid biosynthesis"

i0 = c();for(i in c("Alanine", "Arginine", "Asparagine", "Aspartate", "Cysteine", "Glutamine", "Glutamate", "Glycine", "Histidine", "Isoleucine", "Leucine", "Lysine", "Methionine", "Phenylalanine", "Proline", "Serine", "Threonine", "Tryptophan", "Tyrosine", "Valine")){
    i0 = c(i0, grep(tolower(i),tolower(gBioc$metabolism)))
};rm(i)
gBioc$metabolism[unique(i0)] = "Amino acid biosynthesis"

i0 = c();for(i in c("Glycolysis", "Citrate cycle", "Carbon Metabolism", "Carbohydrate", "Starch", " sugar ")){
    i0 = c(i0, grep(tolower(i),tolower(gBioc$metabolism)))
};rm(i)
gBioc$metabolism[unique(i0)] = "Carbon metabolism"

##### Assign colour to metabolism #####
gbCol = data.frame(metabolism = unique(gBioc$metabolism), cOl = NA)
gbCol$cOl = cBt[1:nrow(gbCol)]
gBioc$cOl = gbCol$cOl[match(gBioc$metabolism, gbCol$metabolism)]
