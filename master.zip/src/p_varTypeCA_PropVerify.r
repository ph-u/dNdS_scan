#!/bin/env Rscript
# author: ph-u
# script: varTypeCA_PropVerify.r
# desc: select a few points to plot on PCoA for verification
# in: Rscript varTypeCA_PropVerify.r
# out: res/vtCA_verSrc.pdf
# arg: 0
# date: 20240310

source("p_src.r"); library(lattice)
cO = read.csv(paste0(pT[1],"vtCA_gene.csv"), header = T, row.names = 1)
iS = read.csv(paste0(pT[1],"vtCA_isolates_Src.csv"), header = T, row.names = 1)
atcg = read.csv(paste0(pT[2],"varTypeProportion_raw.csv"), header = T, row.names = 1)
atcg1 = read.csv(paste0(pT[2],"varTypeProportion.csv"), header = T, row.names = 1)
atcg0 = as.matrix(atcg)
atcg$qD = NA

#cat("High Dim.1, High Dim.2\n")
atcg$qD[which(row.names(atcg) %in% row.names(iS)[which(iS[,1]>.24 & iS[,2]>0)])] = "QHH"

#cat("Zero Dim.1, Zero Dim.2\n")
atcg$qD[which(row.names(atcg) %in% row.names(iS)[which(iS[,1]<.24 & iS[,1]>-.25 & iS[,2]<.1 & iS[,2]>-.2)])] = "Q00"

#cat("Low Dim.1, High Dim.2\n")
atcg$qD[which(row.names(atcg) %in% row.names(iS)[which(iS[,1]<0 & iS[,2]>.1)])] = "QLH"

#cat("Low Dim.1, Low Dim.2\n")
atcg$qD[which(row.names(atcg) %in% row.names(iS)[which(iS[,1]<0 & iS[,2]<(-.2))])] = "QLL"

write.csv(atcg, paste0(pT[2],"vtcaPV.csv"), row.names = T, quote = F)

row.names(atcg0) = atcg$qD
pdf(paste0(pT[2],"varTypeProportion.pdf"), width = 10, height = 50)
levelplot(t(atcg0), col.regions = gray(0:100/100)) # red = large numbers, yellow = small
invisible(dev.off())

#x = c("GCA_015277575.1", "GCA_003840005.1", "GCA_004374095.1", "GCA_003836205.1", "GCA_004378755.1", "GCA_003835445.1", "GCA_003698565.1", "GCA_003839245.1", "GCA_003976685.1", "GCA_004373255.1", "GCA_003975025.1")
#x0 = numeric(length(x))
#for(i in 1:length(x)){x0[i] = grep(x[i], row.names(iS))};rm(i)
#iS0 = iS[x0,]
#row.names(iS0) = paste(1:length(x), row.names(iS0), sep = ".")

#pdf(paste0(pT[2],"vtCA_verSrc.pdf"), width = 10, height = 10)
#plot(x = cO[,1], y = cO[,2], cex = .5, pch = 20, col = "#00000033")
#text(x = iS0[,1], y = iS0[,2], labels = row.names(iS0), col = "#ff0077ff")
#invisible(dev.off())

##### linear model #####
summary(lm(as.numeric(as.factor(atcg$qD)) ~ atcg$A + atcg$T + atcg$C + atcg$G)) # raw count
summary(lm(as.numeric(as.factor(atcg$qD)) ~ atcg1$A + atcg1$T + atcg1$C + atcg1$G)) # relative
