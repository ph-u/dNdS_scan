#!/bin/env Rscript
# author: ph-u
# script: varTypeProportion.r
# desc: investigate varType pattern through ratio of gene variation type
# in: Rscript varTypeProportion.r
# out: NA
# arg: 0
# date: 20240310

qCol = "Src"

source("p_src.r")
load(paste0(pT[1],"vta_data_",qCol,".rda"))

library(lattice)
for(i in 1:ncol(w.AAdf)){
    w.AAdf[,i] = as.character(w.AAdf[,i])
};rm(i)

##### Count sequence variation type #####
cat("Count sequence variation types:",date(),"\n")
for(i in 1:nrow(w.AAdf)){
    cat(i,"/",nrow(w.AAdf),"(",round(i/nrow(w.AAdf)*100,2),"% ) -",date(),"     \r")
    i0 = table(as.character(w.AAdf[i,]))
    if(i==1){
        i1 = unique(unlist(w.AAdf))
        w.vtCount = as.data.frame(matrix(0, nr = nrow(w.AAdf), nc = length(i1)))
        colnames(w.vtCount) = i1
        row.names(w.vtCount) = row.names(w.AAdf)
    };w.vtCount[i,match(names(i0), colnames(w.vtCount))] = i0
};rm(i, i0, i1);cat("\n")
w.vtCount0 = w.vtCount[,c(1,3,2,4)]/ncol(w.AAdf)
for(i in 1:ncol(w.vtCount0)){w.vtCount0[,i] = w.vtCount0[,i]-mean(w.vtCount0[,i])};rm(i)

#pdf(paste0(pT[2],"varTypeProportion.pdf"), width = 10, height = 10)
#par(mar = c(3,3,0,5)+.1)
#levelplot(t(w.vtCount0[,rep(1:ncol(w.vtCount), each = 213)]))
#heatmap(as.matrix(w.vtCount0)) # red = large numbers, yellow = small
#invisible(dev.off())

write.csv(w.vtCount, paste0(pT[2],"varTypeProportion_raw.csv"), row.names = T, quote = F)
write.csv(w.vtCount0, paste0(pT[2],"varTypeProportion.csv"), row.names = T, quote = F)
