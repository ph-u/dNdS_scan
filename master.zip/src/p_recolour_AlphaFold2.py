#!/bin/env python3
# author: ph-u
# script: recolour_AlphaFold2.py
# desc: recolour AlphaFold2 peptide structure
# in: "run /[full_path]/recolour_AlphaFold2.py" -> "loadBfacts [protein_file_basename]"
# out: NA
# arg: 0
# date: 20240212, 20240320

# https://pymol.org/pymol-command-ref.html

# https://stackoverflow.com/questions/10324674/parsing-a-pdb-file-in-python
# https://re-thought.com/how-to-change-or-update-a-cell-value-in-python-pandas-dataframe/
# https://pymol.org/dokuwiki/doku.php?id=start
# https://pymolwiki.org/index.php/Practical_Pymol_for_Beginners
# https://pymolwiki.org/index.php/Movie_pdf
# https://doi.org/10.4310%2FSII.2015.v8.n4.a4

# https://pymolwiki.org/index.php/Simple_Scripting

##### PyMol command sequence #####
## load /media/pokman/HPM-000/current/PhD/1_02_wholeGenomeDNDS/raw/AF-Q9I1T0-F1-model_v4.cif
# run /media/pokman/HPM-000/current/PhD/1_02_wholeGenomeDNDS/src/p_recolour_AlphaFold2.py
## loadBfacts AF-Q9I1T0-F1-model_v4
# bg_color white
# set grid_mode,1
# set label_position,(35,20,0), obj01
# set label_position,(25,15,50), D129
# set label_position,(23,7,50), E153
# set label_position,(25,18,50), H297
# set_name dNdS, dNdS.{ceosu}
# set_name AF-Q9I1J1-F1-model_v4, PA2284.{ceosu}

## load /media/pokman/HPM-000/current/PhD/1_02_wholeGenomeDNDS/p_PA2284/AF-Q9I1J1-F1-model_v4.cif
## loadBfacts AF-Q9I1J1-F1-model_v4

##### PA2934 #####
# load /media/pokman/HPM-000/current/PhD/1_02_wholeGenomeDNDS/raw/AF-Q9HZR3-F1-model_v4.cif
# loadBfacts AF-Q9HZR3-F1-model_v4
# set_name AF-Q9HZR3-F1-model_v4, PA2934.{ce}

# load /media/pokman/HPM-000/current/PhD/1_02_wholeGenomeDNDS/raw/3kd2.cif
# set_name 3kd2, 3kd2.{ce}
# super 3kd2.c, 3kd2.e
# select m, (resi 25-317 and chain {ABCD} and 3kd2.{ce})
# extract m{ABCD}.{ce}, m
# delete 3kd2
# loadBfacts m{ABCD}.{ce}
##################################

##### Get colour reference file #####
import pandas, math
#pT0, pT1 = "/media/pokman/HPM-000/current/PhD/1_02_wholeGenomeDNDS/data/PAO1_107_PA2934_", "--reCon.csv"
pT0, pT1 = "/media/pokman/HPM-000/current/PhD/1_02_wholeGenomeDNDS/data/PAO1_107_PA1500_", "--reCon.csv"
#pT0, pT1 = "/media/pokman/HPM-000/current/PhD/1_02_wholeGenomeDNDS/data/dNdS_reCon_","_strP.csv"
scaleMax, srcNam = [0.,.5], ["Cystic-fibrosis","Environmental","Other-infections","Urban","Unknown"] #["PA2934"] #["Cystic-fibrosis","Environmental","Other-infections","Urban","Unknown"]

d = pandas.read_csv(pT0 + srcNam[0] + pT1)

##### Reset residues colour #####
# https://www.blopig.com/blog/2020/09/pymol-colouring-proteins-by-property/
from pymol import cmd, stored, math

# https://pymolwiki.org/index.php/Load_new_B-factors
sPec, cOlumn = "rainbow", ["dNdS.mean","dNdS"] #["absLOG10","diff_N_p.adj"] #["dNdS.mean","dNdS"]
def loadBfacts (mol, startaa=1, source=d, visual="Y"):
    """usage: loadBfacts mol, [startaa, [source, [visual]]]"""
    source.at[startaa-1,cOlumn[0]] = scaleMax[0]
    source.at[len(source)-1,cOlumn[0]] = scaleMax[1]
    obj = cmd.get_object_list(mol)[0]
    cmd.alter(mol,"b=-1.0")
    counter = int(startaa)
    xMin = min(source[cOlumn[0]])
    if math.isinf(min(source[cOlumn[0]])):
        xMax = max(source[cOlumn[0]])+2
    else:
        xMax = max(source[cOlumn[0]]) # scaleMax

    for x in range(len(source)):
        if math.isinf(source[cOlumn[0]][x]):
            x0 = max(source[cOlumn[0]])+2
        else:
            x0 = source[cOlumn[0]][x]

        cmd.alter("%s and resi %s and n. CA"%(mol,counter), "b=%s"%x0)
        counter += 1
    if visual=="Y":
        cmd.show_as("cartoon", mol)
        cmd.cartoon("automatic", mol)
        cmd.set("cartoon_putty_scale_min", xMin, obj) # min(source[cOlumn])
        cmd.set("cartoon_putty_scale_max", xMax, obj) # max(source[cOlumn]) # 2.5 (dNdS), 1. (prot)
        cmd.set("cartoon_putty_transform", 0, obj)
        cmd.set("cartoon_putty_radius", .1, obj) # peptide string width
# https://pymolwiki.org/index.php/Spectrum
        cmd.spectrum("b", "%s" %sPec, "%s and n. CA " %mol) # apply colour spectrum
        cmd.ramp_new(cOlumn[1], obj, [xMin, xMax], sPec) # [min(source[cOlumn]), max(source[cOlumn])]        cmd.recolor()
#        cmd.set("surface_color", "dNdS", mol ) # "mesh_color" # https://pymolwiki.org/index.php/Expand_To_Surface

cmd.extend("loadBfacts", loadBfacts);
