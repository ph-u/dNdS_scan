#!/bin/bash
# author: ph-u
# script: 01_cdsStEd.sh
# desc: extract genomic cds start-end poistions & functions
# in: bash 01_cdsStEd.sh [../relative/path/2/cds.fa]
# out: data/[cds]_gStEd.csv
# arg: 1
# date: 20231225

# https://unix.stackexchange.com/questions/155805/sed-replace-first-k-instances-of-a-word-in-the-file
gEn=$1
bNam=`basename ${gEn} | cut -f 1 -d "."`
grep -n ">" ${gEn} | sed -e "s/[>,]//g" -e "s/ /,/" -e "s/ /,/" -e "s/ /,/" -e "s/-/,/" -e "s/:/,/" -e "s/:/,/" -e "s/(/,/" -e "s/)/,/" -e "s/;/,/" -e "s/;/,/" -e "s/;product/,product/" -e "s/ = /!/" -e "s/=/,/g" -e "s/!/ = /" -e "s/ ,/,/g" -e "s/, /,/g" | tr -s ","  > ../data/${bNam}_gStEd.csv
grep -v ",name," ../data/${bNam}_gStEd.csv | sed -e "s/,locus_tag/,,,locus_tag/g" > t.txt
grep -e ",name," ../data/${bNam}_gStEd.csv >> t.txt
mv t.txt ../data/${bNam}_gStEd.csv
exit
