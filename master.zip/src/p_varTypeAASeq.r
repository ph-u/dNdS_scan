#!/bin/env Rscript
# author: ph-u
# script: varTypeAASeq.r
# desc: convert variation type data into peptide sequences - row = isolate; col = gene
# in: Rscript varTypeAASeq.r
# out: data/varTypeAASeq.fa
# arg: 0
# date: 20240309, 20240403

library(ape)
source("p_src.r")
f = f[which(f$gEne %in% protList),] # gsub("^01_","00_",list.files(pT[3], "^01_"))

#vt2aa = data.frame(src = c("SNP", "ID", "INDEL", "NoHits", "blastnERR"), aaRes = c("A", "T", "C", "G", "N"))
vt2aa = data.frame(src = c("identical", "indel", "noHit", "SNP"), aaRes = c("A", "T", "C", "G"))

cat("Mapping variation type:", date(), "\n")
for(i in 1:nrow(f)){
    cat(i,"/",nrow(f),"-",round(i/nrow(f)*100,2),"% ;", date(), "       \r")
    i1 = read.csv(paste0(pT[3],"PAO1_107_",f$gEne[i],"--dbSum.csv"), header = T)
    i2 = strsplit(i1$varType, ":")
    names(i2) = row.names(i1) = read.table(text = gsub("_ASM","@",i1$clinical), sep = "@")[,1]
    for(i0 in 1:length(i2)){i1$varType[i0] = i2[[i0]][length(i2[[i0]])]} # only functional sequences
#    i1 = unique(i1)

##### Set recording list #####
    if(i==1){
#        nAm = unique(i1$clinical)
        rEs = as.data.frame(matrix(nr = length(i2), nc = nrow(f))) #vector(mode="list", length = length(i2))
        row.names(rEs) = names(i2) #nAm # result names convenient for mapping
#        nAm = gsub("_genomic.fna","",nAm)
#        for(i0 in 1:length(rEs)){rEs[[i0]] = as.character(numeric(nrow(f)))}
    }

##### Map sequence variation type #####
    rEs[,i] = i1$varType[match(row.names(i1), row.names(rEs))]
#    i1$varType = NA
#    for(i0 in grep("%", i1$locus)){i1$varType[i0] = strsplit(i1$locus[i0],"%")[[1]][1]}
#    i1$varType[is.na(i1$varType)] = "SNP" 
#    i1$aaRes = vt2aa$aaRes[match(i1$varType, vt2aa$src)]

##### Segregate variation type aa code into isolates #####
#    for(i0 in 1:nrow(i1)){rEs[[which(names(rEs)==i1$clinical[i0])]][i] = i1$aaRes[i0]}

};rm(i,i0,i1,i2)

##### Bulk convert sequence types into AA code #####
for(i in 1:nrow(vt2aa)){ rEs[rEs==vt2aa$src[i]] = vt2aa$aaRes[i] };rm(i)

cat("\nExporting variation type aa sequence:",date(),"\n")
#names(rEs) = nAm # rename result fasta names for readability
r0 = vector(mode = "list", length = nrow(rEs))
names(r0) = row.names(rEs)
for(i in 1:length(r0)){ r0[[i]] = as.character(rEs[i,]) };rm(i)
write.FASTA(as.AAbin(r0),paste0(pT[1],"varTypeAASeq.fa"))
cat("Exported variation type aa sequence:",date(),"\n")
