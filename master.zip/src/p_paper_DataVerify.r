#!/bin/env Rscript
# author: ph-u
# script: p_paper_DataVerify.r
# desc: code notes for data checking
# in: Rscript p_paper_DataVerify.r
# out: NA
# arg: 0
# date: 20240428

load("../data/varTypeBar_circle.rda")

# Empharsize CF noHit gene cluster & PA2185
plot(1:nrow(f.r0[[1]]), f.r0[[1]]$noHit, type = "l", xlim = c(2150,2450))
rect(2170, 0, 2430, 15, col = "#00000033")
abline(v = which(row.names(f.r0[[1]])=="PA2185"), col = "#ff00ffff")

# Extract gene annotation from gene loss clustser
# f.r0[[1]][which(row.names(f.r0[[1]])=="PA2047")+(-2:2),]
f.feature = read.table("../raw/features.txt", sep = "\t", header = T, quote="")[,c(4,15,17:24)]
f.ft = f.feature[2170:2430,]
f.r1 = f.ft[which(f.ft$Locus.Tag %in% row.names(f.r0[[1]][2170:2430,][which(f.r0[[1]][2170:2430,"noHit"]>0),])),]

# Psl operon check
f.r1 = f.ft[which(f.ft$Locus.Tag %in% row.names(f.r0[[1]][2200:2430,][which(f.r0[[1]][2200:2430,"noHit"]>0),])),] # exclude reported downregulated metabolic genes
f.r0[[1]][which(row.names(f.r0[[1]])=="PA2231")+(0:11),] # Psl operon
f.r0[[1]][which(row.names(f.r0[[1]])=="PA1430"),] # lasR, comparison
