#!/bin/env Rscript
# author: ph-u
# script: vt_BarSelected.r
# desc: plot diversity of variation type
# in: Rscript vt_BarSelected.r
# out: res/vt_BarSelected.pdf
# arg: 0
# date: 20240325

source("p_src.r")
teS = t(read.csv(paste0(pT[2], "vt_Bar.csv"), header = T, row.names = 1))
paVer = read.table("../raw/PAgene_vertex.csv", header = T, sep = "\t")
u.pa = unique(paVer$vertex)

pdf(paste0(pT[2],"vt_BarSelected.pdf"), height = 2.2*length(u.pa), width = 9)
par(mfrow = c(length(u.pa)+1, 1), mar = c(2,5,2,0)+.1)
for(i in u.pa){
    u.paV = teS[,which(colnames(teS) %in% paVer$PANum[which(paVer$vertex==i)])]
    barplot(u.paV, col = cBp, ylab = "IPCD isolates (%)\n[100% = 854 isolates]", main = paste0(i," vertex"))
};rm(i, u.paV)
plot.new()
legend("topleft", legend = row.names(teS), pch = 20, cex = 2.5, col = cBp, inset = c(0,0), horiz = T)
invisible(dev.off())
