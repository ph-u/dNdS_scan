#!/bin/env Rscript
# author: ph-u
# script: 02_cdsDataFuse.r
# desc: generate gene location map of PAO1 vs IPCD clinical isolates
# in: Rscript 02_cdsDataFuse.r
# out: data/cdsDataFuse.csv
# arg: 0
# date: 20240104

pT = "../data/"
pao1 = read.csv(paste0(pT,"PAO1_107_gStEd.csv"), header = F)[,c(1,2,5,6,9,11)]
pao1 = pao1[order(pao1[,1]),-1]
colnames(pao1) = c("geneID","locStart","locEnd","name","locusTag")
f = list.files(pT,"GCA_")

##### genome mapping result collection #####
paRes = table(pao1$name[which(pao1$name!="")])
paRes = names(paRes[which(paRes==1)])
x0 = match(pao1$name,paRes)
paRes = paRes[x0[!is.na(x0)]]
paStart = as.data.frame(matrix(nr = length(f)+1, nc = length(paRes)+1))
colnames(paStart) = c("strainID",paRes)
paStart$strainID = c("PAO1",gsub("_gStEd.csv","",f))
paStart[1,-1] = pao1$locStart[which(!is.na(x0))]; rm(x0)

for(i in 1:length(f)){
#i=1
    cat(i," / ",length(f),"       \r")
    z = read.table(paste0(pT,f[i]), sep = ";", header = T, quote = "", comment.char = "")
    for(i0 in 2:ncol(paStart)){ if(length(grep(colnames(paStart)[i0],z$geneID))==1){ paStart[which(paStart$strainID==gsub("_gStEd.csv","",f[i])),i0] = z$start[grep(colnames(paStart)[i0],z$geneID)] } }
};rm(i,i0,z)

paStart[is.na(paStart)] = ""
write.csv(paStart, paste0(pT, "cdsDataFuse.csv"), quote = F, row.names = F)
paStart0 = t(paStart[,-1])
colnames(paStart0) = paStart[,1]
write.csv(paStart0, paste0(pT, "cdsDataFuseTransposed.csv"), quote = F, row.names = T)
