#!/bin/env Rscript
# author: ph-u
# script: indelSNP_sum.r
# desc: summarize result in the indel/SNP scan
# in: Rscript indelSNP_sum.r
# out: NA
# arg: 0
# date: 20240323

source("p_src.r")
idSNP = read.csv(paste0(pT[1],"indelSNP.csv"), header = T)

##### indel #####
m = as.data.frame.matrix(table(idSNP[is.na(idSNP$snpCount),c("PAnum","frameshift")]))
m$no.yes.frameshift.ratio = m[,1]/rowSums(m[,-1])
m0 = tapply(idSNP$insertLen[which(idSNP$frameshift==0)], idSNP$PAnum[which(idSNP$frameshift==0)], summary)
m0 = do.call(rbind.data.frame, m0[match(row.names(m), names(m0))])
colnames(m0) = paste0("frameshift.0.Insert.Total.Len.",c("min", "1Q", "median", "mean", "3Q", "max"))
write.csv(cbind(m,m0), paste0(pT[2],"indel_frameshift.csv"), row.names = T, quote = F)

##### SNP #####
m0 = tapply(idSNP$snpCount[is.na(idSNP$frameshift)], idSNP$PAnum[is.na(idSNP$frameshift)], summary)
m = do.call(rbind.data.frame, m0)
row.names(m) = names(m0)
colnames(m) = paste0("SNP.positions.",c("min", "1Q", "median", "mean", "3Q", "max"))
write.csv(m, paste0(pT[2],"SNP_count.csv"), row.names = T, quote = F)

# do.call(rbind,strsplit(as.character(c("ATCGATCG","ATCGATGCATG")), "(?<=.{3})", perl = TRUE))
# strsplit(as.character(c("ATCGATCG","ATCGATGCATG")), "(?<=.{3})", perl = TRUE)
