#!/bin/env Rscript
# author: ph-u
# script: vt_genePCA.r
# desc: sequence variation type PCA
# in: Rscript vt_genePCA.r
# out: NA
# arg: 0
# date: 20240321

library(ggbiplot)
source("p_metabolism_PAO1.r")
teS = read.csv(paste0(pT[2],"vt_Bar.csv"), row.names = 1, header = T)

t0 = prcomp(teS, center = T)

g0 = ggbiplot(t0, var.scale=1, groups=gBioc$metabolism, ellipse=T, ellipse.prob=.95, labels.size=4, varname.size = 4) +
    scale_color_manual(values=setNames(gbCol$cOl, gbCol$metabolism)) + theme_bw() +
	guides(color=guide_legend(title="Metabolism")) +
#	scale_y_continuous(breaks = seq(-10, 10, 5), limits = c(-10, 10))+
#	coord_cartesian(xlim=c(-4.5,4.5))+
	theme(legend.position = 'bottom', legend.direction = "vertical",
        	panel.grid.major = element_blank(),panel.grid.minor = element_blank(),
	        legend.title = element_text(size=18),
	        axis.text=element_text(size=16),axis.title=element_text(size=14),
	        plot.margin=margin(t=0,r=0,b=0,l=1))
ggsave(paste0(pT[2],"vt_genePCA.pdf"), plot=g0, width=11, height=20)
