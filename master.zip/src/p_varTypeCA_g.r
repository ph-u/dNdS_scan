#!/bin/env Rscript
# author: ph-u
# script: varTypeCA_g.r
# desc: Correspondence Analysis of factorized whole genome gene variation type data
# in: Rscript varTypeCA_g.r
# out: res/vtCAg_*.pdf
# arg: 0
# date: 20240309

library(ade4); library(ggplot2); source("p_src.r")
load(paste0(pT[1],"vta_data_Src.rda"))
#load(paste0(pT[1],"vta_data_Loc.rda"))

##### Transpose factor-leveled dataframe #####
cat("Dataframe transpose:",date(),"\n")
for(i in 1:ncol(w.AAdf)){w.AAdf[,i] = as.character(w.AAdf[,i])};rm(i)
w.AAdf = as.data.frame(t(w.AAdf))
row.names(w.AAdf) = read.table(text=gsub("107_","@",gsub(".csv","",list.files(pT[3],"^01_"))), sep="@")[,2]
for(i in 1:ncol(w.AAdf)){w.AAdf[,i] = as.factor(w.AAdf[,i])};rm(i) # barcode form by isolate order

##### Correspondence Analysis #####
# https://www.geeksforgeeks.org/correspondence-analysis-using-r/
cat("Correspondence Analysis:",date(),"\n")
w.mca = dudi.coa(w.AAdf, scannf = F, nf = 2)
cat("Correspondence Analysis done:",date(),"\n")

sCores = as.data.frame(w.mca$li)
colnames(sCores) <- c("Dim.1", "Dim.2")
cO = w.mca$co
cO$cOl = w.Col$tYpe[match(row.names(cO), w.Col$src)]

dCol = isoCol$cOl; names(dCol) = isoCol$src
g0 = ggplot() +
    geom_text(aes(x = sCores$Dim.1, y = sCores$Dim.2, label = row.names(sCores), color="a"), size = 1.5) +
    geom_point(aes(x = cO$Comp1, y = cO$Comp2, color = cO$cOl)) +
    xlab("Dimension 1") + ylab("Dimension 2") + theme_bw() +
    scale_colour_manual(values=c(a="#330033ff"), name = "Vectors") +
    scale_colour_manual(values = dCol, name = "Sample Source")
#    scale_colour_manual(values = dCol, name = "Source Continent")
ggsave(paste0(pT[2],"vtCAg_Src.pdf"), g0)
#ggsave(paste0(pT[2],"vtCAg_Loc.pdf"), g0)

##### Export plot data #####
write.csv(cO, paste0(pT[1],"vtCAg_isolates_Src.csv"), row.names = T, quote = F)
#write.csv(cO, paste0(pT[1],"vtCAg_isolates_Loc.csv"), row.names = T, quote = F)
write.csv(sCores, paste0(pT[1],"vtCAg_gene.csv"), row.names = T, quote = F)

# https://stackoverflow.com/questions/25061822/ggplot-geom-text-font-size-control
