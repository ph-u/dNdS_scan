#!/bin/env Rscript
# author: ph-u
# script: varTypeCA.r
# desc: Correspondence Analysis of factorized whole genome gene variation type data
# in: Rscript varTypeCA.r
# out: res/vtCA_*.pdf
# arg: 0
# date: 20240309

qCol = "Src"

library(ade4); library(ggplot2); library(vegan); source("p_src.r"); source("p_metabolism_PAO1.r")
load(paste0(pT[1],"vta_data_",qCol,".rda"))
#w.AAdf = w.AAdf[,which(f$gEne %in% protList)]
colnames(w.AAdf) = protList
rm(protList, f, PAO1.bioc)
vtBar = read.csv(paste0(pT[2], "vt_Bar.csv"), header = T, row.names = 1)

##### Shannon Diversity Index #####
vtBar$sHannon = diversity(as.matrix(vtBar), index = "shannon")

##### Correspondence Analysis #####
# https://www.geeksforgeeks.org/correspondence-analysis-using-r/
cat("Correspondence Analysis:",date(),"\n")
w.mca = dudi.coa(w.AAdf, scannf = F, nf = 2)
cat("Correspondence Analysis done:",date(),"\n")

sCores = as.data.frame(w.mca$li)
colnames(sCores) <- c("Dim.1", "Dim.2")
sCores$cOl = isoCol$src[match(w.Col$tYpe[match(row.names(sCores), w.Col$src)], isoCol$src)]
#sCores$cOl = w.Col$tYpe[match(row.names(sCores), w.Col$src)]
#row.names(w.mca$co) = read.table(text=gsub("107_","@",gsub(".csv","",list.files(pT[3],"^01_"))), sep="@")[,2]

dCol = isoCol$cOl; names(dCol) = isoCol$src
gG = ggplot() + xlab("Dimension 1") + ylab("Dimension 2") + theme_bw()

g0 = gG +
    geom_text(aes(x = w.mca$co$Comp1, y = w.mca$co$Comp2, label = row.names(w.mca$co), color="a"), size = 1.5) +
#    geom_text(aes(x = sCores$Dim.1, y = sCores$Dim.2, label = apply(read.table(text=row.names(sCores), sep="_")[,1:2],1,function(x){paste0(x, collapse = "_")}), color = sCores$cOl), size = 1.5) +
    geom_point(aes(x = sCores$Dim.1, y = sCores$Dim.2, color = sCores$cOl)) +
    scale_colour_manual(values = dCol, name = "Sample Source") # "Sample Source" "Source Continent" "Source Type"
ggsave(paste0(pT[2],"vtCA_",qCol,".pdf"), g0, width = 10, height = 10)
#ggsave(paste0(pT[2],"vtCA_",qCol,"_tx.pdf"), g0, width = 10, height = 10)

gCol = gBioc$cOl; names(gCol) = gBioc$metabolism
g1 = gG +
    scale_colour_manual(values=gCol, name = "Gene vectors") +
    geom_text(aes(x = w.mca$co$Comp1, y = w.mca$co$Comp2, label = row.names(w.mca$co), color=gBioc$metabolism), size = 1.5)
ggsave(paste0(pT[2],"vtCA_",qCol,"_genes.pdf"), g1, width = 20, height = 10)

g2 = gG +
    geom_text(aes(x = w.mca$co$Comp1, y = w.mca$co$Comp2, label = row.names(w.mca$co), color=vtBar$sHannon), size = 1.5) +
    scale_colour_gradientn(name = "Shannon Diversity Index", colours = rev(grey(seq(.1,1,(1-.1)/nrow(vtBar)))), limits = round(range(vtBar$sHannon), 2))
ggsave(paste0(pT[2],"vtCA_",qCol,"_geneShannon.pdf"), g2, width = 20, height = 10)
# https://stackoverflow.com/questions/21537782/how-to-set-fixed-continuous-colour-values-in-ggplot2
# https://stackoverflow.com/questions/76055759/how-to-use-multiple-colour-scales-in-ggplot2-in-r

##### Export plot data #####
#write.csv(sCores, paste0(pT[1],"vtCA_isolates_",qCol,".csv"), row.names = T, quote = F)
#write.csv(w.mca$co, paste0(pT[1],"vtCA_gene.csv"), row.names = T, quote = F)

# https://stackoverflow.com/questions/25061822/ggplot-geom-text-font-size-control
