#!/bin/env Rscript
# author: ph-u
# script: collectSum_dNdS.r
# desc: collect summaries of median dN/dS values
# in: Rscript collectSum_dNdS.r
# out: res/pca_id*_{sl,bi}.pdf
# arg: 0
# date: 20240317

source("p_src.r")

protList = unname(unlist(read.csv(paste0(pT[1],"PAO1_proteins.txt"), header = F)))
f = list.files(pT[3],"^sDNDS_")
f = data.frame(fNam=f, gEne=read.table(text=gsub("[.]csv","",f), sep = "_")[,4])
f = f[which(f$gEne %in% protList),]; rm(protList)

##### Summarize dN/dS medians under two assumptions of identical sequence segmenets ####
for(i in 1:nrow(f)){
    i0 = read.csv(paste0(pT[3],f$fNam[i]), header = T)
    if(i==1){
        dN.idNA = dN.id00 = as.data.frame(matrix(nr=nrow(i0), nc = nrow(f)+2))
        colnames(dN.idNA) = colnames(dN.id00) = c("strain","sRc",f$gEne)
        dN.idNA$strain = dN.id00$strain = i0[,1]
        dN.idNA$sRc = dN.id00$sRc = mEta$sOurce[match(dN.idNA$strain,mEta$assemblyInfo.genbankAssmAccession)]
    }
## ASSUME dN/dS = inf is standardized to max numeric dN/dS value of the same gene
    for(i1 in 2:ncol(i0)){ if(any(is.infinite(i0[,i1]))){
        i0[which(is.infinite(i0[,i1])),i1] = max(i0[which(is.finite(i0[,i1])),i1], na.rm = T)
    }};rm(i1)

    dN.idNA[,f$gEne[i]] = i0$idNA
    dN.id00[,f$gEne[i]] = i0$id00
};rm(i, i0)
# dN.idNA[1:10,(ncol(dN.idNA)-5):ncol(dN.idNA)] # check inf values

## ASSUME if indel, then gene is not facing selection pressure -- dN/dS = 1
#dN.idNA[is.na(dN.idNA)] = dN.id00[is.na(dN.id00)] = 1

##### PCA with NAs #####
p.idNA = pcaSwap(dN.idNA[,-(1:2)])
p.id00 = pcaSwap(dN.id00[,-(1:2)])

pdf(paste0(pT[2],"pca_idNA_sl.pdf"), width = 10, height = 5)
slplot(p0.idNA <- pca(dN.idNA[,-(1:2)], method = "ppca"))
invisible(dev.off())

pdf(paste0(pT[2],"pca_id00_sl.pdf"), width = 10, height = 5)
slplot(p0.id00 <- pca(dN.id00[,-(1:2)], method = "ppca"))
invisible(dev.off())

pb.NA = ggbiplot(p.idNA, obs.scale = 1, var.scale = 1, groups = as.factor(dN.idNA$sRc), ellipse = TRUE, ellipse.prob = 0.95) + theme_bw() +
    scale_color_manual(values=setNames(cBp[1:length(unique(dN.idNA$sRc))], unique(dN.idNA$sRc))) +
    guides(color=guide_legend(title="Sample source")) +
    theme(legend.position = 'bottom', legend.direction = "vertical",
        panel.grid.major = element_blank(),panel.grid.minor = element_blank(),
	legend.title = element_text(size=18),
	axis.text=element_text(size=16),axis.title=element_text(size=14),
	plot.margin=margin(t=0,r=0,b=0,l=1))
ggsave(paste0(pT[2],"pca_idNA_bi.pdf"), plot = pcaLAB(pb.NA,round(p0.idNA@R2*100,1)), width = 6, height = 7)

pb.00 = ggbiplot(p.id00, obs.scale = 1, var.scale = 1, groups = as.factor(dN.id00$sRc), ellipse = TRUE, ellipse.prob = 0.95) + theme_bw() +
    scale_color_manual(values=setNames(cBp[1:length(unique(dN.id00$sRc))], unique(dN.id00$sRc))) +
    guides(color=guide_legend(title="Sample source")) +
    theme(legend.position = 'bottom', legend.direction = "vertical",
        panel.grid.major = element_blank(),panel.grid.minor = element_blank(),
	legend.title = element_text(size=18),
	axis.text=element_text(size=16),axis.title=element_text(size=14),
	plot.margin=margin(t=0,r=0,b=0,l=1))
ggsave(paste0(pT[2],"pca_id00_bi.pdf"), plot = pcaLAB(pb.00,round(p0.id00@R2*100,1)), width = 6, height = 7)


#plsda.idNA = plsda(dN.idNA[,-(1:2)], as.factor(dN.idNA$sRc))
#plotIndiv(plsda.idNA, pch=20, ellipse=T, ellipse.level=.95, size.xlabel=rel(1.4), size.ylabel=rel(4), size.axis=rel(2), legend=T, style="graphics", cex=3) # col=cBp[1:nrow()]
