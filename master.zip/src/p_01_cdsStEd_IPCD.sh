#!/bin/bash
# author: ph-u
# script: 01_cdsStEd_IPCD.sh
# desc: extract cds metadata for each of the IPCD clinical isolates
# in: bash 01_cdsStEd_IPCD.sh [../relative/path/2/cds.fa]
# out: data/[cds]_gStEd.csv
# arg: 1
# date: 20240104

[[ -z $1 ]]&&head -n 5 $0 | tail -n 1&&exit

gEn=$1
bNam=`basename ${gEn} | sed -e "s/_cds_from_genomic[.]fna//"`
#printf "${bNam}       \r"

[[ -f ../data/${bNam}_gStEd.csv ]]&&rm ../data/${bNam}_gStEd.csv

echo -e "geneID;locus_tag;protein;start;end;type" >> ../data/${bNam}_gStEd.csv
grep -e ">" ${gEn} | sed -e "s/ [[]locus_tag=/;/g" -e "s/[]] [[]protein=/;/" -e "s/ [[]location=/;/g" -e "s/ [[]gbkey=/;/g" | perl -pe "s/[.][.][0-9]+,[0-9]+[.][.]/../g" | sed -e "s/[.][.]/;/" -e "s/[<]//g" -e "s/[()]//g" -e "s/;complement/;/g" -e "s/;join/;/g" | rev | sed -e "s/[]]//" -e "s/[]]//" | rev >> ../data/${bNam}_gStEd.csv

#grep -v "frame;" ../data/${bNam}_gStEd.csv | sed -e "s/protein_id/;;protein_id/g" -e "s/pseudo;/;;pseudo;/g" > ../data/${bNam}_gStEd_t.csv
#grep -e "frame;" ../data/${bNam}_gStEd.csv >> ../data/${bNam}_gStEd_t.csv
#mv ../data/${bNam}_gStEd_t.csv ../data/${bNam}_gStEd.csv
exit
