#!/bin/env Rscript
# author: ph-u
# script: operonMap.r
# desc: make raw table for marking operon
# in: Rscript operonMap.r
# out: res/operonMap.csv
# arg: 0
# date: 20250211

source("p_src.r")
library(ggplot2);library(stringr)

#i0 = c(which(GTF$Locus.Tag=="PA2125"),which(GTF$Locus.Tag=="PA2384"))
#opMap = data.frame(PAnum=GTF$Locus.Tag[i0[1]:i0[2]],gNam=GTF$gNam[i0[1]:i0[2]])
#write.csv(opMap, paste0(pT[1],"operonMap--raw.csv"), quote = F, row.names = F)

opMap$yy = 0
repeat{ p0 = nrow(opMap)
    for(i in 2:nrow(opMap)){opMap$yy[i] = ifelse(opMap$end[i-1]>opMap$start[i],opMap$yy[i-1]+1,opMap$yy[i])};rm(i)
    opMap = opMap[opMap$yy == 0,]
    if(nrow(opMap)==p0){rm(p0);break}
}
i0 = strsplit(opMap$nAm, "-")
opMap$nAmPlot = ""
for(i in 1:nrow(opMap)){if(length(grep("PA",i0[[i]]))!=length(i0[[i]])){opMap$nAmPlot[i] = opMap$nAm[i]}};rm(i,i0)

opMap$yyTxt = 0
opMap$yyTxt[opMap$nAmPlot!=""] = rep(c(1,-1),sum(opMap$nAmPlot!=""))[1:sum(opMap$nAmPlot!="")]

##### plot operon map #####
p0 = ggplot() + theme_minimal() + xlab("") + ylab("") + ylim(c(-1,1)) + coord_radial(r.axis.inside = T, inner.radius = .7) +
     geom_segment(aes(x = opMap$start[opMap$strand=="+"], y=opMap$yy[opMap$strand=="+"], xend = opMap$end[opMap$strand=="+"], yend = opMap$yy[opMap$strand=="+"]), arrow = arrow(length = unit(.5, "cm"))) +
     geom_segment(aes(x = opMap$end[opMap$strand!="+"], y=opMap$yy[opMap$strand!="+"], xend = opMap$start[opMap$strand!="+"], yend = opMap$yy[opMap$strand!="+"]), arrow = arrow(length = unit(.5, "cm"))) +
#     geom_segment(aes(x = rowSums(opMap[opMap$nAmPlot!="",c("start","end")])/2, y=opMap$yy[opMap$nAmPlot!=""], xend = rowSums(opMap[opMap$nAmPlot!="",c("start","end")])/2, yend = opMap$yyTxt[opMap$nAmPlot!=""]*.5), arrow = arrow(length = unit(.2, "cm"))) +
#     geom_text(aes(x = rowSums(opMap[,c("start","end")])/2, y = opMap$yyTxt, label = opMap$nAmPlot), angle = 0) +
     theme(axis.text = element_blank())

ggsave(paste0(pT[2],"operonMap.pdf"), plot = p0, width = 10, height = 10)
